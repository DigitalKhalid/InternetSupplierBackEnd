from django.contrib import admin
from .models import Setting

admin.site.register(Setting)
