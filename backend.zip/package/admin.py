from django.contrib import admin
from .models import PackageSubscriptions

admin.site.register(PackageSubscriptions)
